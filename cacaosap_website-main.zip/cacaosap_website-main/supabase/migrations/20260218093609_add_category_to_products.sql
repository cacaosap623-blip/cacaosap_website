/*
  # Add category support to products table

  1. Changes
    - `products` table now includes `category` column to organize products by category
      - Home: Featured items
      - Wellness: Ceremonial cacao and mental clarity
      - Health: Pure products for heart health and antioxidants
      - Sport: Energy-boosting cacao blends
      - Sustainability: Eco-friendly packaging and fair-trade sourcing
  
  2. Updated Schema
    - New column: `category` (text, not null, default 'Home')
  
  3. Notes
    - Existing products will default to 'Home' category
    - Category values: Home, Wellness, Health, Sport, Sustainability
*/

ALTER TABLE products
ADD COLUMN IF NOT EXISTS category text DEFAULT 'Home' NOT NULL;

-- Update existing products with appropriate categories
UPDATE products SET category = 'Wellness' WHERE name LIKE '%Ceremonial%' OR name LIKE '%Mindful%';
UPDATE products SET category = 'Health' WHERE name LIKE '%Pure%' OR name LIKE '%Heart%' OR name LIKE '%Antioxidant%';
UPDATE products SET category = 'Sport' WHERE name LIKE '%Energy%' OR name LIKE '%Pre%' OR name LIKE '%Workout%';
UPDATE products SET category = 'Sustainability' WHERE name LIKE '%Organic%' OR name LIKE '%Fair%' OR name LIKE '%Eco%';
