/*
  # Create products table for Cacaosap store

  1. New Tables
    - `products`
      - `id` (uuid, primary key) - Unique identifier for each product
      - `name` (text) - Product name
      - `price` (numeric) - Product price
      - `img` (text) - Product image URL
      - `description` (text) - Optional product description
      - `created_at` (timestamp) - Creation timestamp
  
  2. Security
    - Enable RLS on `products` table
    - Add policy to allow anyone to view products (public read)
    - Products are managed by admin only
*/

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price numeric NOT NULL,
  img text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view products"
  ON products
  FOR SELECT
  TO anon, authenticated
  USING (true);
