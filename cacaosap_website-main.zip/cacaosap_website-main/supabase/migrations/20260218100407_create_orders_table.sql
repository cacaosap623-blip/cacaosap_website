/*
  # Create orders table for e-commerce

  1. New Tables
    - `orders`
      - `id` (uuid, primary key)
      - `customer_name` (text)
      - `customer_email` (text)
      - `customer_address` (text)
      - `total_amount` (numeric)
      - `status` (text - pending, completed, shipped)
      - `payment_intent_id` (text - from Stripe)
      - `created_at` (timestamp)
      
  2. Security
    - Enable RLS on `orders` table
    - Allow anyone to insert orders (public checkout)
    - Allow email-based access for order lookup
*/

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  customer_address text NOT NULL,
  total_amount numeric NOT NULL,
  status text DEFAULT 'pending',
  payment_intent_id text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can insert orders"
  ON orders
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can view their own orders"
  ON orders
  FOR SELECT
  TO anon
  USING (customer_email IS NOT NULL);
