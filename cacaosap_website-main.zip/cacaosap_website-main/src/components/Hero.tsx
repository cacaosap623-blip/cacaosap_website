import { Leaf } from 'lucide-react';

export function Hero() {
  return (
    <section className="bg-gradient-to-b from-amber-50 to-white py-16 md:py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="mb-6 flex justify-center">
          <Leaf className="w-12 h-12 text-amber-700" />
        </div>

        <h2 className="text-4xl md:text-5xl font-bold text-amber-950 mb-4">
          Premium Cacao, Sourced Pure
        </h2>

        <p className="text-lg text-stone-600 mb-8 max-w-2xl mx-auto">
          Discover our carefully curated collection of the world's finest cacao products.
          From single-origin dark chocolate to artisan cacao nibs, experience the essence of pure indulgence.
        </p>

        <button className="bg-amber-700 hover:bg-amber-800 text-white px-8 py-3 rounded-lg font-semibold transition-colors inline-block">
          Explore Collection
        </button>
      </div>
    </section>
  );
}
